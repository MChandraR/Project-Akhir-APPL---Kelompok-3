package com.mcr.e_library.ui.fragment

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

class Settings {
    private var menu:ArrayList<String> = ArrayList(listOf("Tema","Bahasa"))

    @Composable
    fun settingsMainView(){
        Column {
            Box(modifier = Modifier.background(Color.White).clip(RoundedCornerShape(0,0,50,0))){
                Text(modifier=Modifier.fillMaxSize().background(Color.Blue),text="Aplikasi Perpustakaan By Kelompok 4")
            }

            LazyColumn(
                modifier=Modifier.weight(.6f),
                content = {
                    items(
                        count = menu.size,
                        itemContent = {
                            Text(modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp),text = menu[it], fontWeight = FontWeight.Bold)
                        }
                    )
                }
            )
        }

    }
}